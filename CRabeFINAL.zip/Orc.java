import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Orc extends GameObject
{
    protected boolean leftOrRight;//true if left false if right
    public Orc(int x, int y)
    {
        super(x, y);
        this.leftOrRight = false;
    }

    @Override
    public void draw(Canvas canvas)
    {
        ImageView im = new ImageView();
        im.setImage(new Image("images/orc.png"));
        GraphicsContext gc = canvas.getGraphicsContext2D();
        canvas.setUserData("Orc");
        gc.drawImage(im.getImage(), 0, 0, canvas.getWidth(), canvas.getHeight());
    }
}
