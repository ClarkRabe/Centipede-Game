public class settingsData
{

    public static int numSegments = 10;
    public static int rockCount = 15;
    public static int highScore = 0;

}
